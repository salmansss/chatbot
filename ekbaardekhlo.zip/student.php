<html>
<link href='style.css' rel='stylesheet'>
<ul>
<li><a href="http://theemcoe.org/about.html">ABOUT</a></li>
<li><a href="student.php">STUDENT</a>
<ul>
<li><a>OUR TEAM</a></li>
<li><a>Camp Sites</a></li>
<li><a href="http://theemcoe.org/vision.html">Mission &amp; Vision</a></li>
<li><a href="Student Corner<svg class="icon icon-angle-down" aria-hidden="true" role="img"> <use href="#icon-angle-down" xlink:href="#icon-angle-down"></use> </svg></a>
<ul class="sub-menu">
	<li id="menu-item-31" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-31"><a href="https://drive.google.com/open?id=0B7_SN3ULA_M_fmc0Rkg2bnZRdnl3blktUEhhWWFiQkpXdDdEb0QxZDk3Z0Vmcms3ejJvbEE">Project Files</a></li>
	<li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="http://goo.gl/forms/0vZ7uDL3to">Train Concession</a></li>
	<li id="menu-item-109" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-109"><a href="https://drive.google.com/drive/folders/0B4dTTaCxQJ2tZ1lCM21VbFVJMW8?usp=sharing">University Question Papers</a></li>
	<li id="menu-item-110" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-110"><a href="http://mechbook.theemmech.in">MechBook</a></li>
	<li id="menu-item-110" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-110"><a href="extra.html">Extra</a></li>
	</ul>
</li></a></li>
</ul>
</li>
<li><a href="visitor.php">VISITOR</a>
<ul>
<li><a>Activities</a></li>
<li><a>Parks</a></li>
<li><a href="canteen.jpg">Canteen</a></li>
<li><a>Events</a></li>
<li><a href="https://muquestionpapers.com/">Download paper</a></li>
</ul>
</li>
<li><a href="query.php">PARENT</a>
<ul>
<li><a href="boisarmap.gif">Map</a></li>
<li><a href="https://www.bing.com/maps?q=boisar+direction&FORM=HDRSC4">Directions</a></li>
<li><a href="http://www.photos.theemmech.in/">Photo Gallery</a></li>
</ul>
</li>
<li><a href="faculty.php">FACULTY</a></li>
<ul>
<li><a href="admin.php">ADMIN</a></li>
</li>
</ul>
<head>
<title>STUDENT</title>
</head>

<body>
<br>
<br>
<br>
<br>
<img src="book.jpg"></img>
<h2>About Student</h2>
<p>The student can log in and ask any kind <br>
of information that is required kindly provide<br>
 a proper login ID</p>
 <center><form name="f" action="student.php" onsubmit="return validation();" method="post"> 
Username : <input type="text" name="Username"><br><br>
Password : <input type="password" name="Password"><br><br>
 <a href="query.php"><input type="submit" name="Submit"></a><br><br>
 </form></center>
<?php

$Username = filter_input(INPUT_POST,'Username');
$Password = filter_input(INPUT_POST,'Password');
if(!empty($Username)){
	if(!empty($Password)){
		$host = "localhost";
		$dbusername = "root";
		$dbpassword = "";
		$dbname ="chatbot";
		
//Create connection
$conn = new mysqli($host,$dbusername,$dbpassword,$dbname);

if(mysqli_connect_error()){
	die('Connect Error ('. mysqli_connect_errno() .')'
	. mysqli_connect_errno());
}
else{
	$sql = "INSERT INTO student (Username,Password)
	values ('$Username','$Password')";
	if($conn->query($sql)){
		echo "New record is inserted sucessfully";
}
else{
	echo "Error: ".$sql ."<br>". $conn->error;
}
$conn->close();
}
}
else{
	echo "Username should not be empty";
	die();
}
}
else{
	echo "Password should not be empty";
	die();
}
?>