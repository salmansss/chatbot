<html>
<link href='style.css' rel='stylesheet'>
<ul>
<li><a href="askedquestion.html">ASKED QUESTION</a></li>
<li><a href="invalidquestion.html">INVALID QUESTION</a>
<ul>
<li><a>Camp Sites</a></li>
<li><a>Mission &amp; Vision</a></li>
<li><a>Resource</a></li>
</ul>
</li>
<li><a href="addquestion.html">ADD QUESTION</a>
<ul>
<li><a>Activities</a></li>
<li><a>Parks</a></li>
<li><a>Canteen</a></li>
<li><a>Events</a></li>
</ul>
</li>
<li><a href="addstudent.html">ADD STUDENT</a>
<ul>
<li><a>Map</a></li>
<li><a>Directions</a></li>
</ul>
</li>
<li><a href="visitordetail.html">VISITOR DETAILS</a></li>
<ul>
<li><a href="homepage.html">LOGOUT</a></li>
</li>
</ul>
<head>
<title>VISITOR DETAIL</title>
</head>

<body>

</body>
<table border="1" width="100%" cellpadding="10">
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
<th>Contact No</th>
<th>Person</th>
<th>Work Type</th>
<th>Purpose</th>
</tr>
<tr>
<td>1</td>
<td>john</td>
<td>abc@gmail.com</td>
<td>98337515624</td>
<td>Rahul</td>
<td>Personal</td>
<td>Commercial</td>
<tr>
<td>2</td>
<td>Salman</td>
<td>abcdd@gmail.com</td>
<td>98337515624</td>
<td>Raj</td>
<td>Personal</td>
<td>Commercial</td>
</table>
</html>

